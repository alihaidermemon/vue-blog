<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" value="<?php echo e(csrf_token()); ?>"/>
    <title><?php echo e(__('Laravel Vue JS CRUD Blog - Compasslist')); ?></title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/plugin/loader/css/main.css')); ?>" type="text/css" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/app.css')); ?>" type="text/css" rel="stylesheet"/>


    <link href="<?php echo e(asset('css/style.css')); ?>" type="text/css" rel="stylesheet"/>
</head>
<body>

<div id="app">
</div>
<script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/customFunction.js')); ?>" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html><?php /**PATH D:\wamp64\www\compasslist\git\vue-blog\resources\views/app.blade.php ENDPATH**/ ?>